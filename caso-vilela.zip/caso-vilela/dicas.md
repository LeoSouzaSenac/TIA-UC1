# 💡 Dicas progressivas

Travou? Vá abrindo uma dica de cada vez — cada uma cobre uma etapa da
investigação. Tente resolver sozinho antes de olhar a próxima.

<details>
<summary>Dica 1 — Por onde começar</summary>

Comece com `ls -la` pra ver o que existe na pasta. Depois leia
`boletim_ocorrencia.txt` e `laudo_necropsia.txt` com `cat`. Anote: onde
aconteceu, em que horário, e que tipo de objeto pode ter sido usado como
arma.
</details>

<details>
<summary>Dica 2 — Quem são os suspeitos</summary>

Leia `convidados.csv` com `cat` pra saber o código de 2 letras de cada
suspeito (ex: OL, BV, RS, MC, HP, TF). Você vai usar esses códigos pra
filtrar os logs mais adiante.
</details>

<details>
<summary>Dica 3 — Os depoimentos</summary>

Leia os 6 arquivos de `depoimentos/` com `cat depoimentos/*.txt`. Cada
pessoa diz onde estava durante a festa. Preste atenção em detalhes que
parecem inofensivos, como descrição de roupas — eles podem ser relevantes
mais adiante.
</details>

<details>
<summary>Dica 4 — Cruzando depoimento com câmera</summary>

Para cada código de suspeito, rode `grep CODIGO logs/registro_cameras.log`
(troque CODIGO por BV, RS, MC, OL, HP, TF, um de cada vez) e compare o
resultado com o que a pessoa disse no depoimento. Um dos seis vai ter uma
contradição clara entre onde disse que estava e onde a câmera mostra que
ele/ela esteve.
</details>

<details>
<summary>Dica 5 — Descartando os outros suspeitos</summary>

Depois de rodar o `grep` pra todos os códigos, confirme que os outros 5
nunca aparecem no 2º andar/escritório durante a janela de horário do
crime. Isso ajuda a eliminar quem tem álibi confirmado, mesmo que tenha
motivo (alguns depoimentos insinuam desavenças ou segredos — nem todo
motivo aponta pro culpado).
</details>

<details>
<summary>Dica 6 — A arma: o que está faltando</summary>

O laudo de necropsia já deu uma pista sobre o material e o formato do
objeto usado. Agora veja `logs/inventario_objetos.txt` — tem algo faltando
lá que combina exatamente com essa descrição.
</details>

<details>
<summary>Dica 7 — Uma pista que não está à vista</summary>

Nem toda evidência está solta na pasta principal. Use `find` pra procurar
por um arquivo relacionado à arma, em qualquer subpasta, mesmo as mais
profundas:
```bash
find . -iname "*algumapalavra*"
```
Troque "algumapalavra" por um termo ligado ao objeto que você identificou
na Dica 6.
</details>

<details>
<summary>Dica 8 — O tecido rasgado</summary>

O boletim de ocorrência menciona um pedaço de tecido rasgado encontrado na
cena. O arquivo que você achou com o `find` na Dica 7 descreve esse
tecido também. Um dos depoimentos descreve, sem querer, uma roupa que bate
com essa descrição. Tente:
```bash
grep -i -r "veludo" .
grep -i -r "dourado" .
```
</details>

<details>
<summary>Dica 9 — A perícia confirma</summary>

Veja o arquivo dentro da pasta `pericia/` com `cat`. Ele cruza impressões
digitais encontradas na arma com o banco de dados dos convidados — e
aponta pra um código específico. Esse código deve ser o mesmo suspeito que
você já suspeita desde a Dica 4.
</details>

<details>
<summary>Dica 10 — O motivo</summary>

Falta entender o "porquê". Dê uma olhada nos arquivos da pasta
`financeiro/`. Um deles menciona uma mudança recente que prejudicava
diretamente o suspeito que você já identificou — um motivo e tanto pra um
crime.
</details>

<details>
<summary>Dica 11 — Fechando o caso</summary>

Você já deve ter tudo: (1) o horário e local do crime, (2) qual suspeito
estava lá nesse horário segundo a câmera — mas negou no depoimento, (3) a
arma encontrada escondida, (4) o tecido que liga a arma a esse suspeito,
(5) a perícia de digitais confirmando, e (6) o motivo financeiro. Junte
tudo numa frase: **quem, com o que, onde e por quê.**
</details>
