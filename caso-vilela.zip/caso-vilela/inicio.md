# 🔎 O Caso da Mansão Vilela

Na noite de sábado, dia 14 de junho, durante a festa de bodas de ouro (50 anos
de casamento) de **Eduardo Vilela**, o anfitrião foi encontrado morto em seu
escritório, no segundo andar da mansão.

Seis pessoas próximas a ele estavam na casa naquela noite. Uma delas é a
culpada. Seu trabalho é descobrir **QUEM matou, COM O QUE (a arma) e ONDE**
exatamente o crime aconteceu, cruzando evidências espalhadas pelos arquivos
deste diretório.

Você só pode usar o **terminal (Git Bash)** para investigar. Nada de abrir os
arquivos no editor de texto clicando — a ideia é treinar comandos.

## Comandos que você vai precisar

Lista rápida abaixo — mas o arquivo **`comandos_referencia.md`** tem cada
um deles detalhado, com todas as opções úteis e exemplos aplicados direto
neste caso.

- `ls`, `ls -la`, `ls -R` — para explorar as pastas
- `cat arquivo` — para ler um arquivo
- `grep "termo" arquivo` — para procurar um termo dentro de um arquivo
- `grep -r "termo" .` — para procurar um termo em TODOS os arquivos de uma pasta
- `grep -i` — busca ignorando maiúsculas/minúsculas
- `grep -E "regex"` — busca com regex (útil pra faixas de horário, tipo `2[2-3]:`)
- `find . -name "*.txt"` — para localizar arquivos por nome/extensão
- `find . -iname "*algumapalavra*"` — para achar arquivos escondidos em subpastas
- `wc -l arquivo` — contar linhas (quantas vezes algo aparece)
- `sort` e `uniq -c` — organizar e contar ocorrências
- `head` / `tail` — ver o início/fim de um arquivo grande
- `diff arquivo1 arquivo2` — comparar dois arquivos e achar diferenças

Se travar em algum ponto da investigação, abra o **`dicas.md`** — ele tem
dicas progressivas (uma pista de cada vez, sem entregar a resposta).

## Por onde começar

1. Leia o `boletim_ocorrencia.txt` e o `laudo_necropsia.txt` — eles dão a
   janela de horário do crime e pistas sobre o tipo de arma.
2. Veja `convidados.csv` para saber quem estava na festa e onde cada um
   deveria estar.
3. Leia os depoimentos em `depoimentos/` — cada suspeito diz onde estava.
   Preste atenção em detalhes que parecem inofensivos (roupas, horários).
4. Cruze os depoimentos com `logs/registro_cameras.log` — as câmeras não mentem.
5. Dá uma olhada em `logs/inventario_objetos.txt` e em `pericia/` para
   descobrir a arma.
6. Tem pelo menos um arquivo importante escondido em subpastas — você vai
   precisar do `find` pra ele.
7. Quando tiver certeza, escreva sua resposta em uma frase:
   **"[Nome] matou [Nome da vítima] com [arma] no/na [local]."**

Boa sorte, detetive. 🕵️
