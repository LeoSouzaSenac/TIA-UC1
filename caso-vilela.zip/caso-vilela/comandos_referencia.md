# 🖥️ Referência de comandos — Git Bash

Guia rápido dos comandos que resolvem esse caso, com as opções mais úteis
e exemplos usando os arquivos reais da investigação.

---

## `ls` — listar arquivos e pastas

| Opção | O que faz |
|---|---|
| `ls` | lista o conteúdo da pasta atual |
| `ls -l` | lista em formato detalhado (tamanho, data) |
| `ls -a` | mostra também arquivos ocultos (que começam com `.`) |
| `ls -la` | combina `-l` e `-a` |
| `ls -R` | lista recursivamente, entrando em todas as subpastas |

```bash
ls -la
ls -R pistas_ocultas
```

---

## `cd` — entrar/sair de pastas

```bash
cd depoimentos      # entra na pasta
cd ..                # volta uma pasta
cd ~                 # volta pra pasta "home"
cd -                 # volta pra última pasta em que você estava
```

---

## `cat` — mostrar o conteúdo de um arquivo

```bash
cat boletim_ocorrencia.txt
cat depoimentos/otavio.txt
cat logs/*.log        # mostra todos os arquivos .log de uma vez
```

---

## `grep` — buscar um termo dentro de arquivo(s)

| Opção | O que faz |
|---|---|
| `-i` | ignora maiúsculas/minúsculas |
| `-r` | busca recursivamente, em todas as subpastas |
| `-n` | mostra o número da linha onde encontrou |
| `-E` | ativa regex estendida (útil pra faixas de horário) |
| `-v` | inverte a busca — mostra as linhas que **não** contêm o termo |
| `-c` | mostra só a contagem de ocorrências, não as linhas |

```bash
grep OL logs/registro_cameras.log          # só as linhas do suspeito OL
grep -i "veludo" -r .                       # busca "veludo" em tudo, ignorando maiúsculas
grep -E "2[2-3]:[0-9]{2}" logs/registro_cameras.log   # horários entre 22:00 e 23:59
grep -n "escritorio" -i depoimentos/*.txt   # em qual linha cada depoimento cita o escritório
```

---

## `find` — localizar arquivos por nome, em qualquer subpasta

| Opção | O que faz |
|---|---|
| `-name "padrão"` | busca por nome exato (case sensitive) |
| `-iname "padrão"` | busca por nome, ignorando maiúsculas/minúsculas |
| `-type f` | só arquivos (não pastas) |
| `-type d` | só pastas |

```bash
find . -iname "*castic*"      # acha arquivo com "castiçal" no nome, onde quer que esteja
find . -name "*.txt"          # todos os .txt do projeto
find pistas_ocultas -type f   # tudo que tem dentro da pasta de pistas ocultas
```

---

## `wc` — contar linhas, palavras, caracteres

```bash
wc -l logs/registro_cameras.log     # quantas linhas (entradas) tem o log
wc -l depoimentos/*.txt              # linhas de cada depoimento
```

---

## `sort` e `uniq` — organizar e contar ocorrências

```bash
grep -o "| [A-Z]* |" logs/registro_cameras.log | sort | uniq -c
# conta quantas vezes cada código de suspeito aparece no log de câmeras
```

---

## `head` e `tail` — ver só o início ou o fim de um arquivo

```bash
head -5 logs/registro_cameras.log    # 5 primeiras linhas
tail -5 logs/registro_cameras.log    # 5 últimas linhas
```

---

## `diff` — comparar dois arquivos e ver as diferenças

```bash
diff depoimentos/otavio.txt logs/registro_cameras.log
```
(Nesse caso os arquivos têm formatos diferentes, então `diff` não é o mais
indicado — mas serve pra comparar, por exemplo, duas versões de um mesmo
arquivo. Pra comparar depoimento x câmera, o mais eficiente aqui é ler os
dois com `cat`/`grep` e comparar manualmente.)
